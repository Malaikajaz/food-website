# WebProject-Group-6(IIUM)
INFO 2302	WEB TECHNOLOGIES
Instructor: AIDRINA BINTI MOHAMED SOFIADIN
Halal Restaurant by Group 6
Prepared by-
Mammi Farjana(1912190)
Anisahtul Nadzirah Roszamri (1916092)
Siti Hasanah binti Mazlan(1918934)
Malaika Pandit(1917494) and
Rayyanur Rahman(1929067)

'Halal Restaurant' is a website for a restaurant based in Kuala Lumpur.

1. Project Description
	“Halal restaurants” is the name of our website.It contains mainly five webpages and each page has a different purpose for the users. We expect the user to browse through the site with ease while keeping the interface simple and concise. While designing the website, we created the necessary webpages required for any restaurant sites like, home page, menu page, while also keeping an about us page and contact us page to make the user feel more involved and interactive. We also included a content dedicated blog page. The purpose of the blog page is to keep the contents of the webpage fresh on a regular basis.

	While developing the website, we attempted to apply different web media such as graphics, audio/video, and interactivity. We also designed the site so that navigation through the site can be easy by applying links in designated places. We plan to enhance our website by using JavaScript in the next part of the project (part2) to make it more interactive and allow fluidity of the website. Another specification considered for the development is API (Application Programing Interface) to magnify the web-surfing experience and also for keeping the website up to date. We also provided a basic layout for each page so that the user can feel familiarity while visiting this website compared to other websites.
 	
	The aim of this project was to understand the firsthand view of what happens at the core of a website developing team. We also caught a glimpse of what happens behind the scenes of any websites we visit in this day and age. Because of this experience we are better prepared for the progression of this project and also ready to adapt, if any shortcoming arises. Furthermore, it also taught us the practical and analytical part of web development. Our expectation is to be able to re-adjust during the latter part of the project, if any re-adjustment is required while also achieving the desired outcome for the project.

2. Conclusion
	By designing this website,we have not only learned the design aspects of web development, but we have also learned how to program in HTML, CSS, and JavaScript. Through evaluating many different webpages, we are aware of what is effective and ineffective to viewers when designing a website too. Through this hands-on project, we were able to understand the frontend of a general website, and the critical thinking as we developed the restaurant site. We were also able to show the creative side, through the layout and design of this project.
In short, the team members feel ease with the good and well result of the project. It is very difficult in the beginning as it is new to all of us and we are also facing some problems here and there during the coding part. It is really satisfying to see the website is in format and be expected like we were planning.
